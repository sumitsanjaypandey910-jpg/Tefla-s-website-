TEFLA'S EXPERIENCES — WEBSITE SOURCE

Pages:
- index.html (home; uploaded MP4 plays as the background hero video)
- about.html
- services.html (all service categories on one page)
- experiences.html (experience highlights and filterable gallery)
- contact.html (booking enquiry form)
- privacy.html, terms.html, cancellation.html (policy placeholders)
- styles.css, script.js
- assets/hero-video.mp4 (provided video)

PREVIEW LOCALLY
1. Unzip this folder.
2. Open index.html in a modern browser. For best results, use a local server:
   - Python: python -m http.server 8000
   - Then open http://localhost:8000
3. Keep the assets folder beside the HTML files; the video path is relative.

BEFORE PUBLISHING
- Replace placeholder phone and office address.
- Replace stock photos with approved event and artist images.
- Replace example testimonials with approved, genuine testimonials.
- Replace policy placeholders with reviewed legal text.
- The booking form opens a pre-filled email to hello@teflasexp.com; it is not a database-backed form. Connect a form service or backend for automatic submissions.
- Update social profile URLs if the official accounts differ.
- Background video is muted by default because browsers restrict autoplay with sound. Visitors can use the on-screen sound button.
- Google Fonts and stock photos use remote URLs and require an internet connection. The uploaded hero video is included locally.
