(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if (menuButton && nav) menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.textContent = open ? '×' : '☰';
  });

  const video = document.querySelector('.hero-media');
  const soundButton = document.querySelector('.sound-toggle');
  if (video && soundButton) {
    // Browsers generally allow autoplay only when muted. Sound is user-activated.
    video.muted = true;
    soundButton.addEventListener('click', async () => {
      video.muted = !video.muted;
      soundButton.textContent = video.muted ? '◖♪' : '♪';
      soundButton.setAttribute('aria-label', video.muted ? 'Turn background video sound on' : 'Mute background video');
      if (!video.paused) return;
      try { await video.play(); } catch (_) { video.muted = true; }
    });
    const playPromise = video.play();
    if (playPromise && playPromise.catch) playPromise.catch(() => { /* poster remains visible if autoplay is blocked */ });
  }

  const filterButtons = document.querySelectorAll('.filter');
  const galleryItems = document.querySelectorAll('.gallery-grid [data-category]');
  filterButtons.forEach(button => button.addEventListener('click', () => {
    filterButtons.forEach(item => item.classList.remove('active'));
    button.classList.add('active');
    const filter = button.dataset.filter;
    galleryItems.forEach(item => item.hidden = filter !== 'all' && item.dataset.category !== filter);
  }));

  const form = document.querySelector('#booking');
  if (form) form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    const value = key => (data.get(key) || 'Not provided').toString().trim();
    const subject = encodeURIComponent('New event enquiry — Tefla’s Experiences');
    const body = encodeURIComponent(
      `New event enquiry for Tefla’s Experiences\n\nName: ${value('name')}\nCompany: ${value('company')}\nEmail: ${value('email')}\nPhone: ${value('phone')}\nEvent date: ${value('date')}\nLocation: ${value('location')}\nEvent type: ${value('eventType')}\nExpected audience: ${value('audience')}\nService: ${value('service')}\nBudget: ${value('budget')}\nArtist / talent: ${value('artist')}\n\nRequirements:\n${value('details')}`
    );
    const status = form.querySelector('.form-status');
    status.textContent = 'Opening your email app with the enquiry details. Please send the email to complete your enquiry.';
    window.location.href = `mailto:hello@teflasexp.com?subject=${subject}&body=${body}`;
  });
})();
